namespace HacBrewPackLz;

/// <summary>The window people see: a list, and what can be done with it. Everything else is a click further away.</summary>
internal sealed class MainWindow : AppWindow
{
    private readonly Session _session;
    private readonly TitleList _list;
    private readonly Button _addFiles;
    private readonly Button _addFolder;
    private readonly Button _search;
    private readonly Button _clear;
    private readonly Button _options;
    private readonly Button _more;
    private readonly Button _chooseKeys;
    private readonly Button _analyze;
    private readonly Button _compress;
    private readonly Button _stop;
    private readonly Button _details;
    private readonly Button _showOutput;
    private readonly ProgressLine _progress;
    private readonly LogView _log;
    private int _refreshPending;
    private SessionSnapshot _state;
    private bool _showDetails;
    private bool _closeWhenIdle;
    private FormWindow? _optionsWindow;
    private Timer? _animation;

    public MainWindow(Session session)
    {
        _session = session;
        _state = session.Snapshot();
        CreateTopLevel(AppInfo.Name, 920, 620, null);

        _list = Add(new TitleList(row => _session.Toggle(row), all => _session.SelectAll(all), row => _session.Remove(row), issue => _session.Remove(issue), Explorer.Show,
            ShowNotes, ShowCompressed));
        _addFiles = Add(new Button("Add files", ButtonStyle.Secondary, AddFiles, Glyph.Add));
        _addFolder = Add(new Button("Add folder", ButtonStyle.Secondary, AddFolder, Glyph.Folder));
        _search = Add(new Button("Search a location", ButtonStyle.Secondary, OpenSearch, Glyph.Search));
        _clear = Add(new Button("Clear", ButtonStyle.Ghost, () => _session.RemoveAll()));
        _options = Add(new Button("Options", ButtonStyle.Ghost, OpenOptions, Glyph.Settings));
        _more = Add(new Button("", ButtonStyle.Ghost, OpenMore, Glyph.More));
        _chooseKeys = Add(new Button("Choose keys", ButtonStyle.Secondary, ChooseKeys));
        _details = Add(new Button("Details", ButtonStyle.Ghost, ToggleDetails));
        _analyze = Add(new Button("Analyze", ButtonStyle.Secondary, () => _session.Analyze()));
        _compress = Add(new Button("Compress", ButtonStyle.Primary, PressCompress) { Menu = OpenCompressMenu });
        _stop = Add(new Button("Stop", ButtonStyle.Secondary, () => _session.Stop()));
        _showOutput = Add(new Button("Show in folder", ButtonStyle.Ghost, ShowLastOutput, Glyph.FolderOpen));
        _progress = Add(new ProgressLine());
        _log = Add(new LogView { Visible = false });

        session.Changed += () =>
        {
            if (Interlocked.Exchange(ref _refreshPending, 1) == 0)
                PostFromWorker();
        };
        DropTarget.Register(Handle, hover =>
        {
            _list.DropHover = hover;
            Invalidate();
        }, files => _session.AddInputs(files));

        Refresh();
        Relayout();
    }

    protected override (int width, int height) MinimumSize => (660, 460);

    protected override void OnMessageFromWorker()
    {
        // The timer only asks for the moving parts to be drawn again.
        if (Interlocked.Exchange(ref _refreshPending, 0) == 1)
            Refresh();
        else
            Invalidate();
    }

    /// <summary>Keeps what moves moving while there's no telling how far along a job is, such as reading files, so it doesn't look stuck.</summary>
    private void Animate(bool on)
    {
        if (on && _animation is null)
            _animation = new Timer(_ => PostFromWorker(), null, 0, 33);
        else if (!on && _animation is not null)
        {
            _animation.Dispose();
            _animation = null;
        }
    }

    protected override void OnThemeChanged() => _log.ApplyTheme();

    /// <summary>What else can be done with what's on the list, from the arrow at the end of the Compress button.</summary>
    private void OpenCompressMenu(Rect below)
    {
        bool repack = _session.Settings.Get("--nocompress") == "1";
        var items = new List<(string, char, Action)>
        {
            (repack ? "Repack" : "Compress", Glyph.Download, PressCompress),
            ("Send to Switch", Glyph.FolderOpen, SendToSwitch),
        };
        if (_state.Rows.Any(r => r.Selected && !r.IsFolder && !r.IsDone(BatchMode.Extract)))
            items.Add(("Extract to folders", Glyph.Folder, () => _session.Extract()));
        int width = S(200);
        _ = new PopupList(this, below with { X = below.Right - width, W = width }, items.ToArray());
    }

    private void PressCompress()
    {
        if (!_state.Rows.Any(r => r.Selected && !r.IsDone(BatchMode.Convert)))
            return;
        var names = _session.TickedWithoutUpdate();
        if (names.Length > 0)
        {
            const int NamesShown = 6;
            string list = string.Join("\n", names.Take(NamesShown)) + (names.Length > NamesShown ? $"\nand {names.Length - NamesShown} more" : "");
            int answer = Win32.MessageBoxW(Handle, $"With compression off, repacking only makes a title smaller by making its update part of it, and these have none:\n\n{list}\n\nUntick them?\n\nNo repacks them too.", AppInfo.Name, Win32.MB_YESNOCANCEL | Win32.MB_ICONINFORMATION);
            if (answer == Win32.IDCANCEL)
                return;
            if (answer == Win32.IDYES)
                _session.UntickWithoutUpdate();
        }
        _session.Compress();
    }

    protected override bool OnClosing()
    {
        if (!_state.IsBusy || _state.Activity is SessionActivity.Reading or SessionActivity.Analyzing)
            return true;
        if (Win32.MessageBoxW(Handle, "A job is still running. Stop it and close?\n\nTitles that have finished are kept.", AppInfo.Name, Win32.MB_YESNO | Win32.MB_ICONWARNING) != Win32.IDYES)
            return false;
        _session.Stop();
        _closeWhenIdle = true;
        return false;
    }

    protected override void OnClosed()
    {
        Animate(false);
        Win32.PostQuitMessage(0);
    }

    protected override bool OnKey(int key)
    {
        if (key == Win32.VK_ESCAPE && _state.IsBusy)
        {
            _session.Stop();
            return true;
        }
        return false;
    }

    private void Refresh()
    {
        var state = _session.Snapshot();
        int ticked = state.Rows.Count(r => r.Selected);
        string compressLabel = (_session.Settings.Get("--nocompress") == "1" ? "Repack" : "Compress") + (ticked < state.Rows.Length && ticked > 0 ? $" {ticked}" : "");
        bool layoutChanged = compressLabel != _compress.Text || state.Rows.Length > 0 != _state.Rows.Length > 0 || state.IsBusy != _state.IsBusy || state.Activity != _state.Activity
            || _list.IsEmpty != (state.Rows.Length == 0 && state.Issues.Length == 0 && state.Notes.Length == 0) || (state.Log.Length > 0) != (_state.Log.Length > 0)
            || (state.KeyProblem is null) != (_state.KeyProblem is null) || (state.Summary is null) != (_state.Summary is null)
            || (state.LastOutput is null) != (_state.LastOutput is null) || (state.Issues.Length == 0) != (_state.Issues.Length == 0);

        _state = state;
        _list.SetData(state);
        _log.SetLines(state.Log);
        _compress.Text = compressLabel;
        UpdateEnabled();
        TaskbarProgress.Set(Handle, ProgressFraction(state));
        bool sliding = state.IsBusy && ProgressFraction(state) is null;
        _progress.Sliding = sliding;
        Animate(sliding);
        if (layoutChanged)
            Relayout();
        Invalidate();
        // It shows how checking for updates is going.
        _optionsWindow?.Invalidate();

        if (_closeWhenIdle && !state.IsBusy)
            Win32.DestroyWindow(Handle);
    }

    /// <summary>How far along the job is, for the bar along the bottom and the taskbar. While sending, that's the file the Switch is reading.</summary>
    private static double? ProgressFraction(SessionSnapshot state)
    {
        if (state.Activity == SessionActivity.Sending)
        {
            if (state.Send is { Reading: { } file } send && send.Files.TryGetValue(file, out var sent) && sent.length > 0)
                return (double)sent.read / sent.length;
            return null;
        }
        if (state.Activity is SessionActivity.Compressing or SessionActivity.Extracting or SessionActivity.Verifying or SessionActivity.Analyzing
            && state.Progress is { Total: > 0 } progress)
            return (double)progress.Done / progress.Total;
        return null;
    }

    private void UpdateEnabled()
    {
        bool idle = !_state.IsBusy;
        _addFiles.Enabled = _addFolder.Enabled = _search.Enabled = _options.Enabled = _more.Enabled = _clear.Enabled = idle;
        _analyze.Enabled = idle && _state.Rows.Any(r => r.Selected && r.NeedsEstimate);
        // Sending still works when everything ticked is already compressed.
        _compress.Enabled = idle && _state.Rows.Length > 0;
        _compress.MainEnabled = _state.Rows.Any(r => r.Selected && !r.IsDone(BatchMode.Convert));
    }

    protected override void Layout(int width, int height)
    {
        if (_list is null)
            return;

        int pad = S(20);
        int top = S(62);
        bool busy = _state.IsBusy;

        // Header
        int headerY = S(16);
        int buttonHeight = S(34);
        _more.Bounds = new Rect(width - pad - S(36), headerY, S(36), buttonHeight);
        int optionsWidth = _options.PreferredWidth();
        _options.Bounds = new Rect(_more.Bounds.X - optionsWidth - S(4), headerY, optionsWidth, buttonHeight);

        // Keys banner
        bool keysMissing = _state.KeyProblem is not null;
        _chooseKeys.Visible = keysMissing;
        if (keysMissing)
        {
            int chooseWidth = _chooseKeys.PreferredWidth();
            _chooseKeys.Bounds = new Rect(width - pad - S(12) - chooseWidth, top + S(11), chooseWidth, buttonHeight);
            top += S(56) + S(12);
        }

        // Bottom bar
        int barHeight = S(68);
        int barY = height - barHeight;
        _progress.Visible = busy;
        _progress.Bounds = new Rect(0, barY, width, S(3));

        int x = width - pad;
        void PlaceRight(Button button, bool visible)
        {
            button.Visible = visible;
            if (!visible)
                return;
            int w = button.PreferredWidth();
            x -= w;
            button.Bounds = new Rect(x, barY + (barHeight - S(36)) / 2, w, S(36));
            x -= S(8);
        }

        // Only what can be done next: nothing until there's something listed, and Analyze while something needs it.
        bool listed = _state.Rows.Length > 0;
        PlaceRight(_stop, busy);
        PlaceRight(_compress, !busy && listed);
        PlaceRight(_analyze, !busy && _state.Rows.Any(r => r.NeedsEstimate));
        PlaceRight(_details, busy || _state.Log.Length > 0);
        PlaceRight(_showOutput, !busy && _state.LastOutput is not null);
        _statusRight = x;

        // Details drawer, which is only there while its button is, then the list takes what's left.
        int listBottom = barY - S(8);
        bool showLog = _showDetails && _details.Visible;
        if (showLog)
        {
            int logHeight = Math.Clamp((listBottom - top) / 2, S(100), S(220));
            _log.Bounds = new Rect(pad, listBottom - logHeight, width - pad * 2, logHeight);
            listBottom -= logHeight + S(10);
        }
        _log.Visible = showLog;

        _list.FooterHeight = _list.IsEmpty ? 0 : 56;
        _list.Bounds = new Rect(pad, top, width - pad * 2, listBottom - top);
        var card = _list.Bounds;

        // The buttons that add things sit in the middle of an empty list, or along the bottom of a full one.
        bool empty = _list.IsEmpty;
        // While the first files are read, the list says so instead.
        _addFiles.Visible = _addFolder.Visible = _search.Visible = !(empty && _state.Activity == SessionActivity.Reading);
        int[] widths = [_addFiles.PreferredWidth(), _addFolder.PreferredWidth(), _search.PreferredWidth()];
        if (empty)
        {
            int total = widths.Sum() + S(8) * 2;
            int y = card.Y + card.H / 2 + S(22);
            int left = card.X + (card.W - total) / 2;
            _addFiles.Bounds = new Rect(left, y, widths[0], S(36));
            _addFolder.Bounds = new Rect(_addFiles.Bounds.Right + S(8), y, widths[1], S(36));
            _search.Bounds = new Rect(_addFolder.Bounds.Right + S(8), y, widths[2], S(36));
            _clear.Visible = false;
        }
        else
        {
            int y = card.Bottom - S(56) + (S(56) - S(34)) / 2;
            int left = card.X + S(12);
            _addFiles.Bounds = new Rect(left, y, widths[0], S(34));
            _addFolder.Bounds = new Rect(_addFiles.Bounds.Right + S(8), y, widths[1], S(34));
            _search.Bounds = new Rect(_addFolder.Bounds.Right + S(8), y, widths[2], S(34));
            _clear.Visible = true;
            int clearWidth = _clear.PreferredWidth();
            _clear.Bounds = new Rect(card.Right - S(12) - clearWidth, y, clearWidth, S(34));
        }
    }

    private int _statusRight;

    protected override void PaintWindow(Gfx g)
    {
        var p = Theme.P;
        int pad = S(20);
        int titleWidth = TextWidth(AppInfo.Name, Fonts.Title);
        g.Text(AppInfo.Name, new Rect(pad + S(4), S(16), titleWidth + S(4), S(34)), Fonts.Title, p.Text);
        g.Text(AppInfo.Version, new Rect(pad + S(4) + titleWidth + S(10), S(21), S(60), S(30)), Fonts.Small, p.Faint);

        if (_state.KeyProblem is not null)
        {
            var banner = new Rect(pad, S(62), ClientWidth - pad * 2, S(56));
            g.FillRound(banner, S(8), p.WarnSurface);
            g.Icon(Glyph.Warning, new Rect(banner.X + S(12), banner.Y, S(24), banner.H), 16, p.Warn);
            int textWidth = _chooseKeys.Bounds.X - banner.X - S(56);
            g.Text("Your keys are needed first", new Rect(banner.X + S(46), banner.Y + S(8), textWidth, S(20)), Fonts.Strong, p.Text);
            g.Text("Put prod.keys beside this program, or drop it on this window.", new Rect(banner.X + S(46), banner.Y + S(28), textWidth, S(18)), Fonts.Small, p.SubText);
        }

        PaintStatus(g);
    }

    private void PaintStatus(Gfx g)
    {
        var p = Theme.P;
        int barHeight = S(68);
        int barY = ClientHeight - barHeight;
        var (first, firstColor, firstFont, second) = StatusText();
        var area = new Rect(S(24), barY, Math.Max(_statusRight - S(36), 0), barHeight);
        bool twoLines = second.Length > 0;
        if (first.Length > 0)
            g.Text(first, area with { Y = barY + (twoLines ? S(13) : 0), H = twoLines ? S(22) : barHeight }, firstFont, firstColor);
        if (twoLines)
            g.Text(second, area with { Y = barY + (first.Length > 0 ? S(36) : 0), H = first.Length > 0 ? S(18) : barHeight }, Fonts.Small, p.SubText, TextFlags.Line);
    }

    private (string first, Rgb firstColor, Font firstFont, string second) StatusText()
    {
        var p = Theme.P;
        var s = _state;
        if (s.Activity == SessionActivity.Reading)
            return (s.ReadingText + "…", p.SubText, Fonts.Body, "");

        if (s.Activity == SessionActivity.Sending)
            return SendingText(s);

        if (s.IsBusy)
        {
            string name = s.Activity switch
            {
                SessionActivity.Analyzing => "Analyzing",
                SessionActivity.Compressing => _session.Settings.Get("--nocompress") == "1" ? "Repacking" : "Compressing",
                SessionActivity.Extracting => "Extracting",
                _ => "Checking",
            };
            string first = s.CurrentCount > 0 ? $"{name} {s.CurrentIndex} of {s.CurrentCount}: {s.CurrentTitle}" : name + "…";
            string second = "";
            if (s.Progress is { } progress)
            {
                _progress.Fraction = ProgressFraction(s) ?? 1;
                var parts = new List<string> { progress.Label };
                if (progress.ShowSizes)
                    parts.Add($"{ProgressReporter.Format(progress.Done)} of {ProgressReporter.Format(progress.Total)}");
                if (progress.ShowSizes && progress.BytesPerSecond > 0)
                    parts.Add($"{progress.BytesPerSecond / 1048576:0} MB/s");
                if (Terminal.TimeLeft(progress) is { Length: > 0 } left)
                    parts.Add(left);
                second = string.Join("  ·  ", parts);
            }
            return (first, p.Text, Fonts.Strong, second);
        }

        string output = _session.Settings.Get("--nspdir") is { Length: > 0 } folder ? $"Saves to {folder}" : "Saves beside the source files";
        if (s.UpdateNote is { } note)
            return (note, p.Text, Fonts.Strong, output);
        if (s.Summary is not null)
        {
            var color = s.SummaryLevel switch { UiLevel.Success => p.Good, UiLevel.Warning => p.Warn, _ => p.Bad };
            return (s.Summary, color, Fonts.Strong, s.LastOutput ?? output);
        }

        if (s.Rows.Length > 0 && !s.Rows.Any(r => r.Selected))
            return ("Nothing is ticked", p.Text, Fonts.Strong, $"Tick the titles you want to work on.  {output}.");

        var known = s.Rows.Where(r => r.Selected && r.Estimate is not null).ToList();
        if (known.Count > 0)
        {
            long before = known.Sum(r => r.InputBytes);
            long after = known.Sum(r => r.Estimate!.OutputBytes);
            long margin = (long)Math.Sqrt(known.Sum(r => (double)r.Estimate!.MarginBytes * r.Estimate.MarginBytes));
            string scope = known.Count == s.Rows.Length ? "" : $" for {known.Count} of {s.Rows.Length} titles";
            string change = after <= before ? $"{TitleList.Percent(before, after)} smaller" : $"{TitleList.Percent(before, after).TrimStart('+')} larger";
            string about = margin > 0 ? "about " : "";
            string estimate = margin > 0 ? $"Estimate, give or take {ProgressReporter.Format(margin)}. " : "";
            return ($"{ProgressReporter.Format(before)} to {about}{ProgressReporter.Format(after)}, {change}{scope}", p.Text, Fonts.Strong, $"{estimate}Nothing has been written.  {output}.");
        }

        return s.Rows.Length > 0
            ? ($"{s.Rows.Length} title{(s.Rows.Length == 1 ? "" : "s")}, {ProgressReporter.Format(s.Rows.Sum(r => r.InputBytes))}", p.Text, Fonts.Strong, $"Analyze shows how small they'd get, without writing anything.  {output}.")
            : ("", p.Text, Fonts.Body, output + ".");
    }

    /// <summary>Everything about sending is said here: whether the Switch is there yet, how to get it there, and what it's reading.</summary>
    private (string first, Rgb firstColor, Font firstFont, string second) SendingText(SessionSnapshot s)
    {
        var p = Theme.P;
        if (s.Send is not { } send)
            return ("Getting ready to send to the Switch…", p.Text, Fonts.Strong, "");
        int compressed = s.Rows.Count(r => r.IsCompressed);
        string sharing = $"Sharing {s.Rows.Length} {(s.Rows.Length == 1 ? "game" : "games")}{(compressed > 0 ? $", {compressed} already compressed" : "")}";
        if (send.Connected.Length == 0)
        {
            _progress.Fraction = 0;
            string how = $"On the Switch, open hacBrewPackLZ: these games come up on Game files, as being on {send.Machine}.";
            string cable = send.UsbProblem is { } problem ? $"  By cable: {problem}" : "  The Switch can be on the same network, or on a USB cable.";
            return ($"{sharing}. Waiting for the Switch", p.Text, Fonts.Strong, how + cable);
        }

        string connected = $"The Switch is connected {string.Join(" and ", send.Connected)}";
        if (send.Reading is not { } file || !send.Files.TryGetValue(file, out var sent))
        {
            _progress.Fraction = 0;
            var all = send.Files.Values;
            long done = all.Sum(f => f.read);
            return ($"{sharing}. {connected}", p.Text, Fonts.Strong, done > 0
                ? $"It has read {ProgressReporter.Format(done)} so far. Choose a game on the Switch to install it."
                : "Choose a game on the Switch to install it. Leave this open until it's done.");
        }

        _progress.Fraction = sent.length > 0 ? (double)sent.read / sent.length : 0;
        var parts = new List<string> { $"{ProgressReporter.Format(sent.read)} of {ProgressReporter.Format(sent.length)}" };
        if (send.BytesPerSecond > 0)
        {
            parts.Add($"{send.BytesPerSecond / 1048576.0:0.0} MB/s");
            long left = (sent.length - sent.read) / Math.Max(send.BytesPerSecond, 1);
            if (left > 0)
                parts.Add(left >= 60 ? $"about {(left + 30) / 60} min left" : $"about {left} s left");
        }
        parts.Add(connected.Replace("The Switch is connected", "connected"));
        return ($"Sending {Path.GetFileName(file)}", p.Text, Fonts.Strong, string.Join("  ·  ", parts));
    }

    /// <summary>What there is to know about a title, below its info button.</summary>
    private void ShowNotes(TitleRow row, Rect button)
    {
        _ = new NotePopup(this, button, row.Notes);
    }

    private void ShowCompressed(bool show)
    {
        _session.Settings.Set("--showcompressed", show ? "1" : "0");
        _session.Settings.Save();
        _session.OptionChanged("--showcompressed");
    }

    private void AddFiles()
    {
        var files = FileDialogs.OpenFiles(Handle, "Add game files", "Game files", GameArchive.DialogFilter, multiple: true);
        if (files.Count > 0)
            _session.AddInputs(files);
    }

    private void AddFolder()
    {
        var folders = FileDialogs.OpenFolders(Handle, "Add game folders, or folders to search for game files and game folders", multiple: true);
        if (folders.Count > 0)
            _session.AddInputs(folders);
    }

    private void OpenSearch() => new SearchWindow(this, files => _session.AddInputs(files)).ShowModalOver(this);

    private void ChooseKeys()
    {
        var files = FileDialogs.OpenFiles(Handle, "Choose your keys file", "Keys", "*.keys;*.txt;*.dat;*.ini", multiple: false);
        if (files.Count == 0)
            return;
        _session.Settings.Set("--keyset", files[0]);
        _session.Settings.Save();
        _session.ReloadKeys();
    }

    private void OpenOptions()
    {
        var store = new SettingsStore(_session);
        _optionsWindow = new FormWindow(this, "Options", OptionCatalog.GeneralGroups, store, [new FormAction("Done", ButtonStyle.Primary, () => null)],
            _ => _session.CheckForUpdates(), _ => _state.UpdateNote);
        _optionsWindow.ShowModalOver(this);
    }

    private void OpenMore()
    {
        var items = new (string, char, Action)[]
        {
            ("Check an NSP…", Glyph.Check, OpenVerify),
            ("About", Glyph.Info, ShowAbout),
        };
        var anchor = _more.Bounds with { X = _more.Bounds.Right - S(210), W = S(210) };
        _ = new PopupList(this, anchor, items);
    }

    /// <summary>Shares every game on the list. The status line along the bottom says how it's going.</summary>
    private void SendToSwitch() => _session.SendToSwitch();

    private void OpenVerify()
    {
        var store = new LocalStore();
        var group = new OptionGroup("Check an NSP",
        [
            new OptionSpec("nsp", "NSP file", OptionKind.File, OptionUse.Build, "Reads it back and checks every hash, block and table.") { Placeholder = "Choose a file" },
            new OptionSpec("romfs", "Compare with a RomFS folder", OptionKind.Folder, OptionUse.Build, "Optional. Compares the game data with these files, byte for byte.") { Placeholder = "None" },
            new OptionSpec("exefs", "Compare with an ExeFS folder", OptionKind.Folder, OptionUse.Build, "Optional.") { Placeholder = "None" },
        ]);
        var actions = new[]
        {
            new FormAction("Check", ButtonStyle.Primary, () =>
            {
                string nsp = store.Get("nsp");
                if (nsp.Length == 0)
                    return "Choose an NSP file first.";
                _session.Verify(nsp, EmptyToNull(store.Get("romfs")), EmptyToNull(store.Get("exefs")));
                return null;
            }),
        };
        new FormWindow(this, "Check an NSP", [group], store, actions).ShowModalOver(this);
    }

    private static string? EmptyToNull(string value) => value.Length > 0 ? value : null;

    private void ShowAbout() => Win32.MessageBoxW(Handle,
        $"{AppInfo.Name} {AppInfo.Version}\n\nBuilds NSP files, and converts NSP, NSZ, XCI and XCZ files to them, with the game data LZ4 compressed through the NCA compression layer. Your original files are never changed.\n\nFree software under the GNU General Public License, version 2.",
        $"About {AppInfo.Name}", Win32.MB_OK | Win32.MB_ICONINFORMATION);

    private void ShowLastOutput()
    {
        if (_state.LastOutput is { } path)
            Explorer.Show(path);
    }

    private void ToggleDetails()
    {
        _showDetails = !_showDetails;
        Relayout();
    }
}
