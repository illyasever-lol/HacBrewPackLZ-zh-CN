// What people can do: ticking games, the + menu and the questions it asks, choosing a folder, and the settings.
#include "app_internal.h"

#include "../core/remote.h"

namespace hbp {

using namespace app;

void App::showMessage(const std::string& title, const std::string& text) {
    auto dialog = std::make_unique<Dialog>();
    dialog->title = title;
    dialog->paragraphs = {text};
    dialog->choices = {{"OK", nullptr}};
    dialog->cancelChoice = 0;
    _dialog = std::move(dialog);
    _dirty = true;
}

void App::showToast(const std::string& text) {
    constexpr double ToastSeconds = 2.2;
    _toast = text;
    _toastUntil = _time + ToastSeconds;
    _dirty = true;
}

void App::showAbout() {
    auto dialog = std::make_unique<Dialog>();
    dialog->title = format("hacBrewPackLZ %s", AppVersion);
    dialog->paragraphs.push_back("Stores games compressed, in the form the firmware itself reads, so they take up less room and play the same.");
    dialog->paragraphs.push_back("Keys: " + (_keysPath.empty() ? std::string("not found") : _keysPath));
    if (_log)
        dialog->paragraphs.push_back("What it does is written to " + _logPath);
    dialog->paragraphs.push_back("Free software under the GNU General Public License, version 2. USB drives are read with libusbhsfs, NTFS-3G and lwext4, under the same licence.");
    dialog->choices = {{"OK", nullptr}};
    dialog->cancelChoice = 0;
    _dialog = std::move(dialog);
    _dirty = true;
}

// -------------------------------------------------------------------------------------------------------------------
// Ticking

void App::toggleRow(int index) {
    sys::Lock lock(_mutex);
    auto rows = visibleRowsLocked(_tab);
    if (index < 0 || index >= (int)rows.size())
        return;
    Row& row = *rows[(size_t)index];
    if (!row.blocked.empty())
        return;
    row.ticked = !row.ticked;
    row.byHand = true;
    _dirty = true;
}

void App::tickAll(bool ticked) {
    sys::Lock lock(_mutex);
    for (auto* row : visibleRowsLocked(_tab)) {
        if (row->blocked.empty()) {
            row->ticked = ticked;
            row->byHand = true;
        }
    }
    _dirty = true;
}

void App::tickWorthIt() {
    sys::Lock lock(_mutex);
    for (auto* row : visibleRowsLocked(_tab))
        row->byHand = false;
    judgeAllLocked();
}

bool App::tickActionChangesLocked(TickAction action) {
    for (auto* row : visibleRowsLocked(_tab)) {
        if (!row->blocked.empty())
            continue;
        bool wanted = action == TickAction::All || (action == TickAction::WorthIt && row->belowMinimum.empty() && row->state != RowState::Done);
        if (row->ticked != wanted)
            return true;
    }
    return false;
}

/// How many ways the button goes round. With compression off, no game saves anything to go by, so there's nothing between all and none.
int App::tickActionCount() const { return _settings.compress ? 3 : 2; }

/// What pressing the button would do next, leaving out whatever wouldn't change anything.
App::TickAction App::nextTickActionLocked() {
    static const TickAction order[] = {TickAction::All, TickAction::None, TickAction::WorthIt};
    int count = tickActionCount();
    for (int i = 0; i < count; i++) {
        TickAction action = order[(_tickStep[_tab] + i) % count];
        if (tickActionChangesLocked(action))
            return action;
    }
    return order[_tickStep[_tab] % count];
}

const char* App::tickActionLabel(TickAction action) {
    switch (action) {
        case TickAction::All:
            return "Tick all";
        case TickAction::None:
            return "Untick all";
        case TickAction::WorthIt:
            break;
    }
    return "Worth it only";
}

void App::cycleTicks() {
    TickAction action;
    {
        sys::Lock lock(_mutex);
        action = nextTickActionLocked();
        _tickStep[_tab] = ((int)action + 1) % tickActionCount();
    }
    switch (action) {
        case TickAction::All:
            tickAll(true);
            showToast("Everything ticked");
            break;
        case TickAction::None:
            tickAll(false);
            showToast("Nothing ticked");
            break;
        case TickAction::WorthIt:
            tickWorthIt();
            showToast("Only what's worth it ticked");
            break;
    }
}

/// What's done to ticked games, done to the one selected, leaving the rest ticked as they were afterwards.
void App::onlyTheSelected(std::function<void()> action) {
    {
        sys::Lock lock(_mutex);
        auto rows = visibleRowsLocked(_tab);
        int index = _focus[_tab];
        if (index < 0 || index >= (int)rows.size())
            return;
        _savedTicks.clear();
        for (int i = 0; i < (int)rows.size(); i++) {
            Row& row = *rows[(size_t)i];
            _savedTicks.emplace_back(row.key, std::make_pair(row.ticked, row.byHand));
            row.ticked = i == index;
            row.byHand = true;
        }
        _dirty = true;
    }
    action();
}

void App::restoreTicks() {
    sys::Lock lock(_mutex);
    for (auto& saved : _savedTicks) {
        Row* row = findLocked(saved.first);
        if (row && row->state != RowState::Done) {
            row->ticked = saved.second.first;
            row->byHand = saved.second.second;
        }
    }
    _savedTicks.clear();
    judgeAllLocked();
}

std::vector<std::string> App::tickedGames() {
    std::vector<std::string> keys;
    sys::Lock lock(_mutex);
    for (auto* row : visibleRowsLocked(_tab)) {
        if (row->ready && row->ticked && row->blocked.empty() && row->extracted.empty())
            keys.push_back(row->key);
    }
    return keys;
}

// -------------------------------------------------------------------------------------------------------------------
// The lists

void App::setTab(int tab) {
    if (tab == _tab || tab < 0 || tab >= TabCount)
        return;
    _tab = tab;
    _focusShown = _focus[tab];
    _scrollShown = _scroll[tab];
    _dirty = true;
    // A list that hasn't come up yet goes first, as it's what's being looked at. What it took the place of picks up again by itself afterwards.
    if (tab != TabSettings && !_scanned[tab] && _jobKind == JobKind::Scanning && _scanningTab != tab)
        _scanStop = true;
}

std::string App::sortDescription() {
    switch (_settings.sort) {
        case 0:
            return _sortedByGain[_tab] ? "best saving first" : "by name until they're analyzed";
        case 1:
            return "largest first";
        default:
            return "by name";
    }
}

void App::changeSort(int direction) {
    _settings.sort = (_settings.sort + direction + 3) % 3;
    saveSettings();
    sys::Lock lock(_mutex);
    _focus[TabInstalled] = _focus[TabFiles] = 0;
    sortRowsLocked();
    _dirty = true;
}

void App::hideFocused() {
    sys::Lock lock(_mutex);
    auto rows = visibleRowsLocked(_tab);
    int index = _focus[_tab];
    if (index < 0 || index >= (int)rows.size())
        return;
    std::string key = rows[(size_t)index]->key;
    _hidden.insert(key);
    saveHiddenLocked();
    _rows.erase(std::remove_if(_rows.begin(), _rows.end(), [&](const Row& r) { return r.key == key; }), _rows.end());
    _focus[_tab] = std::max(0, std::min(index, (int)rows.size() - 2));
    _listChanged = true;
    _dirty = true;
}

void App::showHidden() {
    quietenWorker();
    {
        sys::Lock lock(_mutex);
        _hidden.clear();
        saveHiddenLocked();
    }
    _scanned[TabInstalled] = !_console;
    forgetFileScan();
}

void App::setHideDone(bool hide) {
    _settings.hideCompressed = hide;
    saveSettings();
    sys::Lock lock(_mutex);
    _dirty = true;
}

/// The list of game files shows what's known of under where it now looks straight away, and looks through it all again.
void App::lookElsewhere() {
    forgetFileScan();
    std::vector<std::string> roots = fileRoots();
    sys::Lock lock(_mutex);
    showIndexRowsLocked(indexedPathsLocked(roots), false);
}

void App::chooseFilesFolder() {
    browse("Where to look for game files", _settings.filesFolder, "Look everywhere", [this](const std::string& path) {
        quietenWorker();
        _settings.filesFolder = path;
        saveSettings();
        lookElsewhere();
    });
}

/// Turns one of the places the list looks on or off, and looks again.
void App::toggleSource(bool& source) {
    quietenWorker();
    source = !source;
    saveSettings();
    lookElsewhere();
}

/// Forgets what was worked out for what's ticked, or for everything if nothing is, so that it gets worked out again.
void App::analyzeAgain() {
    quietenWorker();
    int count = 0;
    {
        sys::Lock lock(_mutex);
        auto rows = visibleRowsLocked(_tab);
        bool anyTicked = std::any_of(rows.begin(), rows.end(), [](const Row* row) { return row->ticked && row->blocked.empty(); });
        for (auto* row : rows) {
            if (!row->blocked.empty() || (anyTicked && !row->ticked))
                continue;
            _cache.erase(cacheKey(*row));
            row->hasEstimate = false;
            row->belowMinimum.clear();
            row->byHand = false;
            if (row->state == RowState::Failed)
                row->state = RowState::Ready;
            row->message.clear();
            if (!anyTicked)
                row->ticked = row->state != RowState::Done;
            count++;
        }
        _cacheChanged = true;
        _sortedByGain[_tab] = false;
        sortRowsLocked();
        _dirty = true;
    }
    _autoAnalyze[_tab] = true;
    showToast(count == 1 ? "Analyzing it again" : format("Analyzing %d games again", count));
}

void App::refreshList() {
    quietenWorker();
    if (_tab == TabInstalled) {
        _scanned[_tab] = !_console;
    } else {
        // Asking for it is asking for all of it to be looked at again, even what doesn't look like it's changed.
        std::vector<std::string> roots = fileRoots();
        {
            sys::Lock lock(_mutex);
            for (auto& item : _fileIndex) {
                if (isWithinAny(item.first, roots))
                    item.second.size = -1;
            }
        }
        forgetFileScan();
    }
    showToast("Looking through the list again");
}

// -------------------------------------------------------------------------------------------------------------------
// Jobs, and the questions before them

void App::stopAnalyzing() {
    _autoAnalyze[_tab] = false;
    _sink->stop = true;
}

bool App::stopAsked() const { return _sink->stop; }

/// Whoever wants to get on with it needn't wait: what's still unknown gets worked out as each game's turn comes, and a list coming up gives
/// way and picks up again afterwards. Only with nothing ticked yet does the list on the screen get to come up first.
void App::doWhenFree(std::function<void()> action) {
    bool toAnalyze;
    {
        sys::Lock lock(_mutex);
        toAnalyze = !keysToAnalyzeLocked(_tab).empty();
    }
    bool ready = canActNow();
    if (_jobKind == JobKind::Scanning && (ready || _scanningTab != _tab))
        _scanStop = true;
    if (_analystRunning)
        stopAnalyzing();
    else if (toAnalyze || !_scanned[_tab])
        _autoAnalyze[_tab] = false;
    if (!busy() && ready) {
        confirmTicked();
        action();
    } else {
        _afterWork = std::move(action);
    }
}

/// Whether there's something to act on yet: the list on the screen has come up, or games on it are ticked already. Game files that are
/// only remembered from last time count, as what's left of them gets looked at before anything is done.
bool App::canActNow() {
    if (_scanned[_tab])
        return true;
    sys::Lock lock(_mutex);
    for (auto* row : visibleRowsLocked(_tab)) {
        if (row->ticked && row->blocked.empty() && (row->ready || row->tab == TabFiles))
            return true;
    }
    return false;
}

/// A list of game files that gave way part way through shows some of them as they were last time. Those that are ticked can be acted on all
/// the same, as long as all their files are still there.
void App::confirmTicked() {
    if (_scanned[_tab] || _tab != TabFiles)
        return;
    std::vector<std::pair<std::string, std::vector<std::string>>> toCheck;
    {
        sys::Lock lock(_mutex);
        for (auto* row : visibleRowsLocked(_tab)) {
            if (!row->ticked || !row->blocked.empty() || row->ready)
                continue;
            std::vector<std::string> files = row->dlcFiles;
            for (auto* file : {&row->mainFile, &row->updateFile, &row->extracted}) {
                if (!file->empty())
                    files.push_back(*file);
            }
            toCheck.emplace_back(row->key, std::move(files));
        }
    }
    for (auto& [key, files] : toCheck) {
        bool there = !files.empty();
        for (auto& file : files) {
            try {
                there = there && sys::exists(file);
            } catch (const ToolError&) {
                there = false;
            }
        }
        if (!there)
            continue;
        sys::Lock lock(_mutex);
        for (auto& row : _rows) {
            if (row.tab == TabFiles && row.key == key)
                row.ready = true;
        }
    }
}

void App::pressCompress() {
    _installNow = false;
    _keepGamesWithoutUpdates = false;
    doWhenFree([this] { askToCompress(); });
}

void App::pressInstall() {
    _installNow = true;
    _keepGamesWithoutUpdates = false;
    doWhenFree([this] { askToCompress(); });
}

void App::pressQuit() {
    // Just looking to see if there's a newer version isn't anything to bring up, only getting one is.
    bool updating;
    {
        sys::Lock lock(_mutex);
        updating = _updating && _updateState.rfind("Getting", 0) == 0;
    }
    bool analyzing = _analystRunning;
    auto dialog = std::make_unique<Dialog>();
    dialog->title = "Quit hacBrewPackLZ?";
    if (analyzing)
        dialog->paragraphs.push_back("It's still analyzing. What's been worked out so far is kept, and the rest gets done next time.");
    else if (updating)
        dialog->paragraphs.push_back("It's in the middle of updating itself. That gets stopped, and tried again next time.");
    dialog->choices.push_back({analyzing || updating ? "Keep going" : "Stay", nullptr});
    dialog->choices.push_back({"Quit", [this] { _quit = true; }});
    dialog->cancelChoice = 0;
    // B and then A to leave, and B twice comes back to where it was.
    dialog->focus = 1;
    _dialog = std::move(dialog);
    _dirty = true;
}

void App::beginJob(JobKind kind, const std::vector<std::string>& keys, std::function<void()> work) {
    prepareJob(keys, kind);
    _screen = Screen::Job;
    runInBackground(kind, std::move(work));
}

void App::beginCompress(const std::vector<std::string>& keys) {
    if (!keys.empty())
        beginJob(JobKind::Compressing, keys, [this, keys] { compress(keys); });
}

void App::beginCheck() {
    if (_workerRunning)
        return;
    std::vector<std::string> keys = tickedGames();
    if (keys.empty())
        showMessage("Nothing is ticked", "Press A on the games you want to check, then try again.");
    else
        beginJob(JobKind::Checking, keys, [this, keys] { check(keys); });
}

void App::beginExtract() {
    if (_workerRunning)
        return;
    std::vector<std::string> keys = tickedGames();
    if (keys.empty())
        showMessage("Nothing is ticked", "Press A on the games you want to extract, then try again.");
    else
        beginJob(JobKind::Extracting, keys, [this, keys] { extract(keys); });
}

/// With compression off, a game only comes out any smaller by having an update made part of it, so there's nothing in it for the others. They
/// may well be ticked for something else, so nothing happens to them without asking. True if it has asked.
bool App::askAboutGamesWithoutUpdates() {
    if (_settings.compress || _keepGamesWithoutUpdates)
        return false;
    std::vector<std::string> names;
    {
        sys::Lock lock(_mutex);
        for (auto* row : visibleRowsLocked(_tab)) {
            bool beingInstalled = row->tab != TabInstalled && goesOnConsole(*row);
            if (row->ticked && row->blocked.empty() && !row->hasUpdate && row->extracted.empty() && !beingInstalled)
                names.push_back(row->name);
        }
    }
    if (names.empty())
        return false;

    auto dialog = std::make_unique<Dialog>();
    bool one = names.size() == 1;
    dialog->title = one ? "This game has no update" : format("%d games have no update", (int)names.size());
    dialog->paragraphs.push_back(std::string("With compression off, repacking only makes a game smaller by making its update part of it. ") + (one ? "This one would come out the same size, and it would take time for nothing, so it can be unticked." : "These would come out the same size, and it would take time for nothing, so they can be unticked."));
    dialog->paragraphs.push_back(someNames(names, 3) + ".");
    dialog->choices.push_back({one ? "Untick it" : "Untick them", [this] {
        bool anyLeft = false;
        {
            sys::Lock lock(_mutex);
            for (auto* row : visibleRowsLocked(_tab)) {
                if (row->ticked && row->blocked.empty() && !row->hasUpdate && row->extracted.empty()) {
                    row->ticked = false;
                    row->byHand = true;
                }
                anyLeft = anyLeft || (row->ticked && row->blocked.empty());
            }
            _dirty = true;
        }
        if (anyLeft)
            askToCompress();
        else
            showMessage("Nothing left to repack", "None of the games that were ticked has an update to make part of it.");
    }});
    dialog->choices.push_back({one ? "Repack it too" : "Repack them too", [this] {
        _keepGamesWithoutUpdates = true;
        askToCompress();
    }});
    dialog->choices.push_back({"Cancel", nullptr});
    dialog->cancelChoice = 2;
    _dialog = std::move(dialog);
    _dirty = true;
    return true;
}

void App::askToCompress() {
    if (_workerRunning)
        return;
    if (askAboutGamesWithoutUpdates())
        return;

    int count = 0, unknown = 0, extracted = 0, onConsole = 0, toFile = 0;
    i64 saved = 0;
    {
        sys::Lock lock(_mutex);
        for (auto* row : visibleRowsLocked(_tab)) {
            if (!row->ticked || !row->blocked.empty())
                continue;
            count++;
            extracted += row->extracted.empty() ? 0 : 1;
            if (goesOnConsole(*row))
                onConsole++;
            else
                toFile++;
            if (row->hasEstimate)
                saved += row->estimate.savedBytes();
            else
                unknown++;
        }
    }
    bool replacing = _tab == TabInstalled && replacesInstalled();
    bool installing = _tab != TabInstalled && onConsole > 0;
    std::string word = installing ? "Install" : verb();
    std::string lower = word;
    lower[0] = (char)tolower((u8)lower[0]);
    if (count == 0) {
        showMessage("Nothing is ticked", "Press A on the games you want to " + lower + ", then try again.");
        return;
    }

    if (onConsole > 0 && _settings.compress && !_platform.firmwareReadsCompression()) {
        showMessage("This firmware is too old", "Games stored this way need firmware 12.0.0 or newer. Saving an NSP still works: you can choose that in the settings.");
        return;
    }

    // Better said now than found out part of the way through.
    std::string folder = nspFolder();
    if (toFile > 0) {
        sys::makeDirectories(folder);
        if (!sys::isDirectory(folder)) {
            showMessage("That folder can't be reached", "NSPs are set to go in " + folder + ", which isn't there. If it's on a USB drive, plug it in. You can choose another folder in the settings.");
            return;
        }
    }
    RoomPlan plan = planRoom();
    std::string notFitting = someNames(plan.wontFit, 3);
    bool tooLarge = plan.reason.find("can't hold") != std::string::npos;
    if (plan.order.empty()) {
        if (tooLarge)
            showMessage("That won't fit", notFitting + ": " + plan.reason + ". FAT32 stops at 4 GB, so exFAT or NTFS is what it takes.");
        else
            showMessage("There isn't enough room", format("%s: %s more needs to be free on %s.", notFitting.c_str(), formatSize(plan.mostNeeded).c_str(), plan.reason.c_str()));
        return;
    }

    int going = (int)plan.order.size();
    auto dialog = std::make_unique<Dialog>();
    dialog->title = going == 1 ? word + " this game?" : format("%s these %d games?", word.c_str(), going);
    auto say = [&](const std::string& paragraph) { dialog->paragraphs.push_back(paragraph); };
    if (saved > 0 && replacing)
        say(unknown > 0 ? format("This frees about %s, and whatever the ones not analyzed yet gain.", formatSize(saved).c_str()) : format("This frees about %s.", formatSize(saved).c_str()));
    if (replacing) {
        say(std::string(_settings.compress ? "Each game is replaced by a compressed copy of itself." : "Each game is replaced by a repacked copy of itself, with any update made part of it.") + (_settings.checkResult ? " The copy is written and checked first, and only then does the original go." : " The copy is written first, and only then does the original go.") + " Save data isn't touched.");
        say("Games stored this way need sigpatches to start, and official updates won't install over them.");
        if (!_settings.warned)
            say("First time on this console? Try a small game first and make sure it starts, before doing more.");
    } else if (_tab == TabInstalled) {
        say("The installed games stay as they are, and no space is freed. An NSP of each is saved in " + folder + ".");
    } else if (installing) {
        std::string then = _settings.deleteInstalled ? "Once it's in, the file is deleted." : "The file itself isn't changed.";
        say(std::string(_settings.compress ? "Each one is compressed, unless it already is, and installed on the SD card" : "Each one is installed on the SD card as it is") + ", taking the place of any older copy of the game. " + then + " Games stored this way need sigpatches to start.");
    } else if (extracted < count) {
        say(std::string(_settings.compress ? "A compressed NSP" : "An NSP") + " of each is saved in " + folder + ". The file itself isn't changed.");
    }
    if (extracted > 0 && !installing)
        say(std::string(extracted == 1 ? "An NSP of the extracted game" : "An NSP of each extracted game") + " is saved in " + folder + ", and the folders aren't changed.");
    if (!notFitting.empty())
        say(notFitting + (tooLarge ? ": " + plan.reason + ", so left out." : format(": left out, as %s more would have to be free on %s.", formatSize(plan.mostNeeded).c_str(), plan.reason.c_str())));
    if (_memoryLimited)
        say("This was opened from the album, which leaves little memory to work with. For big games, hold R while starting a game to open it instead.");
    int battery = _platform.batteryPercent();
    if (battery >= 0 && battery < 30 && !_platform.isCharging())
        say(format("The battery is at %d%%. It's best to plug the console in: this can take a while.", battery));

    std::vector<std::string> keys = plan.order;
    dialog->choices.push_back({word, [this, keys] {
        if (!_settings.warned) {
            _settings.warned = true;
            saveSettings();
        }
        beginCompress(keys);
    }});
    dialog->choices.push_back({"Not now", nullptr});
    dialog->cancelChoice = 1;
    _dialog = std::move(dialog);
    _dirty = true;
}

void App::askToStop() {
    int left;
    {
        sys::Lock lock(_mutex);
        left = _jobCount - _jobIndex;
    }
    auto dialog = std::make_unique<Dialog>();
    dialog->title = "Stop?";
    dialog->paragraphs = {"The game being worked on stays exactly as it was. Games already finished stay as they are now."};
    dialog->choices.push_back({"Keep going", nullptr});
    if (left > 0 && !_stopAfterGame)
        dialog->choices.push_back({"After this game", [this] { _stopAfterGame = true; }});
    dialog->choices.push_back({"Stop now", [this] { _sink->stop = true; }});
    dialog->cancelChoice = 0;
    _dialog = std::move(dialog);
    _dirty = true;
}

void App::askToRemove(bool allTicked) {
    std::vector<std::string> keys, names;
    bool installed = false, anyFolder = false, anyFile = false;
    i64 bytes = 0;
    {
        sys::Lock lock(_mutex);
        auto rows = visibleRowsLocked(_tab);
        int index = _focus[_tab];
        for (int i = 0; i < (int)rows.size(); i++) {
            const Row& row = *rows[(size_t)i];
            if (allTicked ? !(row.ticked && row.blocked.empty()) : i != index)
                continue;
            keys.push_back(row.key);
            names.push_back(row.name);
            bytes += row.now;
            installed = installed || row.tab == TabInstalled;
            anyFolder = anyFolder || !row.extracted.empty();
            anyFile = anyFile || (row.tab != TabInstalled && row.extracted.empty());
        }
    }
    if (keys.empty())
        return;
    bool one = keys.size() == 1;
    std::string what = installed ? "Uninstall" : "Delete";
    std::string things = installed ? (one ? "game" : "games") : anyFolder && anyFile ? "items" : anyFolder ? (one ? "folder" : "folders") : (one ? "file" : "files");
    auto dialog = std::make_unique<Dialog>();
    dialog->title = one ? what + " " + names[0] + "?" : format("%s %d %s?", what.c_str(), (int)keys.size(), things.c_str());
    // Most of a list can be ticked without anyone having ticked it, so it says exactly what's about to go.
    if (!one)
        dialog->paragraphs.push_back(someNames(names, 6) + ".");
    dialog->paragraphs.push_back(installed ? format("This takes %s off the console, with updates and DLC. Save data stays.", formatSize(bytes).c_str()) : format("This deletes %s. It can't be undone.", formatSize(bytes).c_str()));
    dialog->choices.push_back({one ? "Keep it" : "Keep them", nullptr});
    dialog->choices.push_back({what, [this, keys] {
        doWhenFree([this, keys] {
            beginJob(JobKind::Removing, keys, [this, keys] { remove(keys); });
            _autoAnalyze[_tab] = true;
        });
    }});
    dialog->cancelChoice = 0;
    dialog->focus = 0;
    _dialog = std::move(dialog);
    _dirty = true;
}

// -------------------------------------------------------------------------------------------------------------------
// The + menu

/// What the menu needs to know about the list, to offer only what makes sense for it.
struct App::MenuFacts {
    size_t hidden = 0;
    size_t toAnalyze = 0;
    int rows = 0;
    int ticked = 0;
    int doneHidden = 0;
    int doneShown = 0;
    bool anyFile = false;
    /// What removing the selected game, or the ticked ones, is called here.
    std::string removeThis;
    std::string removeTicked;
    std::string aboutName;
    std::vector<std::string> about;
};

App::MenuFacts App::menuFacts() {
    MenuFacts facts;
    sys::Lock lock(_mutex);
    facts.hidden = _hidden.size();
    facts.toAnalyze = keysToAnalyzeLocked(_tab).size();
    facts.doneHidden = doneHiddenLocked(_tab);
    bool tickedFolder = false, tickedFile = false;
    auto shown = visibleRowsLocked(_tab);
    for (auto* row : shown) {
        facts.rows++;
        bool isTicked = row->ticked && row->blocked.empty();
        facts.ticked += isTicked ? 1 : 0;
        facts.anyFile = facts.anyFile || row->extracted.empty();
        facts.doneShown += isDoneLocked(*row) ? 1 : 0;
        tickedFolder = tickedFolder || (isTicked && !row->extracted.empty());
        tickedFile = tickedFile || (isTicked && row->extracted.empty());
    }
    int index = _focus[_tab];
    if (index >= 0 && index < (int)shown.size()) {
        const Row& focused = *shown[(size_t)index];
        facts.about = focused.notes;
        facts.aboutName = focused.name;
        if (focused.state != RowState::Working)
            facts.removeThis = focused.tab == TabInstalled ? (_console ? "Uninstall this game" : "") : !focused.extracted.empty() ? "Delete this folder" : "Delete this file";
    }
    if (_tab == TabInstalled)
        facts.removeTicked = _console ? "Uninstall the ticked games" : "";
    else
        facts.removeTicked = tickedFolder && tickedFile ? "Delete the ticked files and folders" : tickedFolder ? "Delete the ticked folders" : "Delete the ticked files";
    return facts;
}

void App::openMenu(int page) {
    MenuFacts facts = menuFacts();
    auto menu = std::make_unique<Menu>();
    auto add = [&](const std::string& label, std::function<void()> action) {
        Menu::Item item;
        item.label = label;
        item.action = std::move(action);
        menu->items.push_back(std::move(item));
    };
    auto addSetting = [&](const std::string& label, std::function<std::string()> value, std::function<void(int)> change) {
        Menu::Item item;
        item.label = label;
        item.value = std::move(value);
        item.change = std::move(change);
        menu->items.push_back(std::move(item));
    };
    auto addPage = [&](const std::string& label, int to) { add(label + " ...", [this, to] { openMenu(to); }); };

    switch (page) {
        case MenuSources: {
            auto source = [&](const std::string& label, bool Settings::*flag) {
                addSetting(label, [this, flag]() -> std::string { return _settings.*flag ? "Shown" : "Not shown"; }, [this, flag](int) { toggleSource(_settings.*flag); });
            };
            source("The SD card", &Settings::fromSd);
            source("USB drives", &Settings::fromUsb);
            source("PCs on the network", &Settings::fromPcNetwork);
            source("A PC on the USB cable", &Settings::fromPcCable);
            add(_settings.filesFolder.empty() ? "Only look in one folder" : "Look in one folder: " + _settings.filesFolder, [this] { chooseFilesFolder(); });
            break;
        }
        case MenuThisGame:
            if (!facts.about.empty()) {
                add(format("About this game (%d)", (int)facts.about.size()), [this, about = facts.about, name = facts.aboutName] {
                    _menu.reset();
                    showMessage(name, joined(about, "\n\n"));
                });
            }
            if (_tab != TabInstalled && _console)
                add("Install this game", [this] { onlyTheSelected([this] { pressInstall(); }); });
            if (facts.anyFile) {
                add("Extract this game", [this] { onlyTheSelected([this] { doWhenFree([this] { beginExtract(); }); }); });
                add("Check this game for damage", [this] { onlyTheSelected([this] { doWhenFree([this] { beginCheck(); }); }); });
            }
            add("Analyze this game again", [this] { onlyTheSelected([this] { analyzeAgain(); }); });
            add("Hide this game from the list", [this] { hideFocused(); });
            if (!facts.removeThis.empty())
                add(facts.removeThis, [this] { askToRemove(false); });
            break;
        case MenuTicked:
            if (facts.anyFile) {
                add("Extract the ticked games", [this] { doWhenFree([this] { beginExtract(); }); });
                add("Check the ticked games for damage", [this] { doWhenFree([this] { beginCheck(); }); });
            }
            add("Analyze the ticked games again", [this] { analyzeAgain(); });
            if (!facts.removeTicked.empty())
                add(format("%s (%d)", facts.removeTicked.c_str(), facts.ticked), [this] { askToRemove(true); });
            break;
        case MenuList:
            add("Refresh the list", [this] { refreshList(); });
            if (facts.rows > 0 && facts.ticked == 0)
                add("Analyze every game again", [this] { analyzeAgain(); });
            if (facts.doneHidden > 0)
                add(format("Show the games that are done (%d)", facts.doneHidden), [this] { setHideDone(false); });
            else if (facts.doneShown > 0)
                add("Hide the games that are done", [this] { setHideDone(true); });
            if (facts.hidden > 0)
                add(format("Show the hidden games again (%d)", (int)facts.hidden), [this] { showHidden(); });
            break;
        default:
            addSetting("Sort by", [this]() -> std::string {
                static const char* const names[] = {"Best saving", "Size", "Name"};
                return names[_settings.sort];
            }, [this](int direction) { changeSort(direction); });
            if (facts.ticked > 0 && _tab != TabInstalled && _console)
                add("Install the ticked games", [this] { pressInstall(); });
            if (_analystRunning && _analyzingTab == _tab)
                add("Stop analyzing", [this] { stopAnalyzing(); });
            else if (!_autoAnalyze[_tab] && facts.toAnalyze > 0)
                add(format("Go on analyzing (%d left)", (int)facts.toAnalyze), [this] { _autoAnalyze[_tab] = true; });
            if (_tab != TabInstalled)
                addPage("Where to look", MenuSources);
            if (facts.rows > 0)
                addPage("This game", MenuThisGame);
            if (facts.ticked > 0)
                addPage(format("Ticked games (%d)", facts.ticked), MenuTicked);
            addPage("The list", MenuList);
            break;
    }
    menu->page = page;
    // It opens where it is, rather than coming from wherever it was last time.
    _glideList = -1;
    _menu = std::move(menu);
    _dirty = true;
}

// -------------------------------------------------------------------------------------------------------------------
// Choosing a folder

void App::browse(const std::string& title, const std::string& start, const std::string& useDefaultLabel, std::function<void(const std::string&)> choose) {
    _browser.reset(new Browser);
    _glideList = -1;
    _browser->title = title;
    _browser->useDefaultLabel = useDefaultLabel;
    _browser->choose = std::move(choose);
    _browseFrom = _screen;
    _screen = Screen::Browse;
    _drives = _platform.drives();
    browseTo(!start.empty() && sys::isDirectory(start) ? start : std::string());
}

void App::browseTo(std::string path) {
    Browser& browser = *_browser;
    browser.path = path;
    browser.entries.clear();
    browser.problem.clear();
    browser.focus = 0;
    browser.scroll = 0;
    _dirty = true;

    if (path.empty()) {
        for (auto& drive : _platform.drives())
            browser.entries.push_back(Browser::Entry{drive.name, drive.root, ""});
        // A PC running hacbrewpacklz send, over the network or a cable.
        for (auto& peer : remote::peers())
            browser.entries.push_back(Browser::Entry{peer.name, "pc:" + peer.id + "/", ""});
        return;
    }

    std::vector<std::string> names;
    try {
        for (auto& entry : sys::list(path)) {
            if (entry.isDirectory)
                names.push_back(entry.name);
        }
    } catch (const ToolError& e) {
        // Most likely a PC that isn't there, or isn't answering.
        browser.problem = e.what();
        logLine(path + ": " + e.what());
        return;
    }
    std::sort(names.begin(), names.end(), lessNoCase);
    auto skip = _platform.foldersToSkip();
    // Saying which are games means looking inside each, which is only worth it for a folder of a sensible size.
    constexpr size_t MostToLookInto = 256;
    for (auto& name : names) {
        std::string full = joinPath(path, name);
        if (std::any_of(skip.begin(), skip.end(), [&](const std::string& s) { return equalsNoCase(full, s); }))
            continue;
        std::string note;
        try {
            note = names.size() <= MostToLookInto && ExtractedGame::isOne(full) ? "Extracted game" : "";
        } catch (const ToolError&) {
        }
        browser.entries.push_back(Browser::Entry{name, full, note});
    }
}

void App::browseInto(int index) {
    if (index >= 0 && index < (int)_browser->entries.size())
        browseTo(_browser->entries[(size_t)index].path);
}

void App::closeBrowser() {
    _browser.reset();
    _screen = _browseFrom;
    _dirty = true;
}

void App::browseUp() {
    std::string from = _browser->path;
    if (from.empty()) {
        closeBrowser();
        return;
    }
    bool isRoot = false;
    for (auto& drive : _platform.drives())
        isRoot = isRoot || equalsNoCase(drive.root, from);
    // A PC's own folder, pc:<name>/, is as far up as it goes there.
    isRoot = isRoot || (remote::isRemote(from) && from.find('/') == from.size() - 1);
    std::string to;
    if (!isRoot) {
        size_t slash = from.find_last_of('/');
        if (slash != std::string::npos) {
            to = from.substr(0, slash);
            // Up to a root keeps the slash that makes it one.
            if (!to.empty() && (to.back() == ':' || (remote::isRemote(to) && to.find('/') == std::string::npos)))
                to += '/';
        }
        for (auto& drive : _platform.drives()) {
            if (equalsNoCase(drive.root, to + "/"))
                to = drive.root;
        }
    }
    browseTo(to);
    for (size_t i = 0; i < _browser->entries.size(); i++) {
        if (equalsNoCase(_browser->entries[i].path, from))
            _browser->focus = (int)i;
    }
}

/// The folder being looked at, or with an empty path, whatever's usual. By value, as it's usually the browser's own, which goes first.
void App::browseChoose(std::string path) {
    auto choose = _browser->choose;
    closeBrowser();
    choose(path);
}

void App::browseUse() {
    if (!_browser->path.empty())
        browseChoose(_browser->path);
}

void App::browseUseDefault() {
    if (!_browser->useDefaultLabel.empty())
        browseChoose("");
}

// -------------------------------------------------------------------------------------------------------------------
// Settings, and the welcome screen

std::string App::shownFolder(const std::string& path, const char* otherwise) {
    if (path.empty())
        return otherwise;
    for (auto& drive : _platform.drives()) {
        if (startsWithNoCase(path, drive.root)) {
            std::string rest = path.substr(drive.root.size());
            return drive.name + ": /" + (rest.empty() || rest[0] != '/' ? rest : rest.substr(1));
        }
    }
    return path;
}

static std::function<std::string()> onOff(const bool& setting) {
    return [&setting] { return setting ? std::string("On") : std::string("Off"); };
}

App::OptionItem App::installedGamesOption(const char* section) {
    return OptionItem{section, "Installed games", "Replacing frees the space, once the new copy has been written. Saving an NSP leaves the game as it is and frees nothing.",
                      [this] { return replacesInstalled() ? std::string("Replace them") : std::string("Save an NSP"); },
                      [this](int) {
                          _settings.replaceInstalled = !_settings.replaceInstalled;
                          saveSettings();
                      }};
}

App::OptionItem App::gameFilesOption(const char* section, const char* help) {
    return OptionItem{section, "Game files and folders", help,
                      [this] { return _settings.installFiles ? std::string("Install them") : std::string("Save an NSP"); },
                      [this](int) {
                          _settings.installFiles = !_settings.installFiles;
                          saveSettings();
                          // What's ticked, and what's done, depends on whether game files get installed.
                          sys::Lock lock(_mutex);
                          judgeAllLocked();
                      }};
}

App::OptionItem App::nspFolderOption(const char* section) {
    return OptionItem{section, "NSP files go in", "Press A to choose a folder, on the SD card or a USB drive.",
                      [this] { return shownFolder(nspFolder(), ""); },
                      [this](int) {
                          browse("Where NSP files go", nspFolder(), "Use the usual folder", [this](const std::string& path) {
                              _settings.nspFolder = path;
                              saveSettings();
                          });
                      },
                      true};
}

App::OptionItem App::minimumSavingOption(const char* section) {
    return OptionItem{section, "Minimum saving", "Games that would save less than this are left unticked, so the time goes where it gains the most. You can still tick them yourself.",
                      [this] { return _settings.minSaving == 0 ? std::string("Off") : format("%d%%", _settings.minSaving); },
                      [this](int direction) {
                          _settings.minSaving = nextChoice(MinSavingChoices, _settings.minSaving, direction);
                          saveSettings();
                          sys::Lock lock(_mutex);
                          judgeAllLocked();
                      },
                      false, true};
}

App::OptionItem App::autoUpdateOption(const char* section) {
    return OptionItem{section, "Automatic updates", "Each time it opens, it looks for a newer version and installs it, if the console is online. Whatever it gets has to carry the right signature.", onOff(_settings.autoUpdate),
                      [this](int) {
                          _settings.autoUpdate = !_settings.autoUpdate;
                          saveSettings();
                      }};
}

/// What's being worked out at the moment is for the settings as they were, and everything that was worked out for them has to be again.
void App::compressionChanged() {
    quietenWorker();
    saveSettings();
    sys::Lock lock(_mutex);
    for (auto& row : _rows) {
        row.hasEstimate = false;
        row.belowMinimum.clear();
        if (row.state == RowState::Failed) {
            row.state = RowState::Ready;
            row.message.clear();
        }
        recallEstimateLocked(row);
    }
    judgeAllLocked();
    _autoAnalyze[TabInstalled] = _autoAnalyze[TabFiles] = true;
}

void App::buildOptions() {
    _options.clear();
    auto add = [this](const char* section, const char* label, const char* help, std::function<std::string()> value, std::function<void(int)> change, bool action = false) {
        _options.push_back(OptionItem{section, label, help, std::move(value), std::move(change), action});
    };
    auto toggle = [this](bool& setting) {
        return [this, &setting](int) {
            setting = !setting;
            saveSettings();
        };
    };

    const char* section = "Which games are worth it";
    _options.push_back(minimumSavingOption(section));
    add(section, "Hide games under 1 MB", "Leaves out games that small with no update or DLC, which is what forwarders are.", onOff(_settings.hideSmall), [this](int) {
        _settings.hideSmall = !_settings.hideSmall;
        saveSettings();
        sys::Lock lock(_mutex);
        _dirty = true;
    });
    add(section, "Hide games that are done", "Leaves off what there's nothing left to do with: installed games once they're compressed, and game files once their game is installed compressed, or once they're compressed if they're saved as NSPs. The + menu brings them back.",
        onOff(_settings.hideCompressed), [this](int) { setHideDone(!_settings.hideCompressed); });

    section = "Compression";
    add(section, "Compression", "Off, games are repacked just as they are, with an update made part of the game and no ticket needed. That's quicker, and a game only comes out smaller if it had an update.", onOff(_settings.compress), [this](int) {
        _settings.compress = !_settings.compress;
        compressionChanged();
        // What only goes with compressing comes and goes with it.
        _rebuildOptions = true;
    });
    add(section, "Compression level", "1 is the fastest and 12 the smallest. 9 is a good balance. Each level has to be analyzed on its own.", [this] { return format("%d", _settings.level); }, [this](int direction) {
        _settings.level = std::max(1, std::min(12, _settings.level + direction));
        compressionChanged();
    });
    _options.back().repeats = true;
    add(section, "Block size", "Larger blocks compress better. 64 KB is what retail games use. Each size has to be analyzed on its own.", [this] { return format("%d KB", _settings.blockSize / 1024); }, [this](int direction) {
        _settings.blockSize = nextChoice(BlockSizeChoices, _settings.blockSize, direction);
        compressionChanged();
    });
    _options.back().repeats = true;

    section = "What to do with them";
    _options.push_back(installedGamesOption(section));
    _options.push_back(gameFilesOption(section, "Saving leaves an NSP in the NSP folder. Installing puts the game where Install games to says, ready to play. The + menu can also install what's ticked, whatever this says."));
    add(section, "Install games to", "Where a game from a file or folder goes. A game that's already installed stays where it is when it's replaced.",
        [this] { return _settings.installToConsole ? std::string("Console") : std::string("SD card"); }, toggle(_settings.installToConsole));
    add(section, "Once a file is installed", "Deleting frees the room the file took up, and only happens once the game has been installed and checked. Nothing else ever touches a file.",
        [this] { return _settings.deleteInstalled ? std::string("Delete it") : std::string("Keep it"); }, toggle(_settings.deleteInstalled));
    add(section, "Check what's written", "Compares what's written with what it should be, and reads some of the game back through the new copy before the original goes. Off is quicker, as whatever fits in memory then doesn't have to be read back at all, but a failing card wouldn't get caught.",
        onOff(_settings.checkResult), toggle(_settings.checkResult));
    add(section, "Run the processor faster", "Takes less time and uses more battery while it works, the way the console does while loading a game.", onOff(_settings.boost), toggle(_settings.boost));

    section = "Folders";
    _options.push_back(nspFolderOption(section));
    add(section, "Extracted games go in", "Press A to choose a folder, on the SD card or a USB drive. They're on the list of game files from there.", [this] { return shownFolder(extractFolder(), ""); }, [this](int) {
        browse("Where extracted games go", extractFolder(), "Use the usual folder", [this](const std::string& path) {
            quietenWorker();
            _settings.extractFolder = path;
            saveSettings();
            forgetFileScan();
        });
    }, true);

    section = "This app";
    _options.push_back(autoUpdateOption(section));
    add(section, "Keep a log", "Writes what the app does to a file on the SD card, which is what to look at or send if something goes wrong. It takes a little more writing to the card.", onOff(_settings.writeLog), [this](int) {
        _settings.writeLog = !_settings.writeLog;
        saveSettings();
        {
            sys::Lock lock(_logMutex);
            _log.reset();
        }
        if (_settings.writeLog) {
            _logPosition = 0;
            openLog();
        }
    });
    add(section, "Check for updates now", "Looks for a newer version on GitLab, and installs it if there is one.", [this] {
        sys::Lock lock(_mutex);
        return _updateState;
    }, [this](int) { startUpdateCheck(true); }, true);
    add(section, "Welcome screen", "Shows what came up the first time this was opened, with the most important settings all in one place.", [] { return std::string(); }, [this](int) {
        _welcomeFocus = 0;
        _screen = Screen::Welcome;
        _dirty = true;
    }, true);
    add(section, "About", "The version, where the keys came from, and where the log is.", [] { return std::string(); }, [this](int) { showAbout(); }, true);

    // What most people will never need to change is out of the way until it's asked for.
    static const char* const Rarely[] = {"Keep a log", "Hide games under 1 MB", "Compression", "Compression level", "Block size", "Once a file is installed", "Check what's written", "Run the processor faster", "Automatic updates", "Check for updates now", "Welcome screen", "About"};
    if (!_settings.moreSettings) {
        _options.erase(std::remove_if(_options.begin(), _options.end(), [](const OptionItem& item) {
            return std::any_of(std::begin(Rarely), std::end(Rarely), [&](const char* label) { return item.label == label; });
        }), _options.end());
    }
    // With compression off, nothing gets compressed or saves anything to go by, so these have nothing to say.
    static const char* const OnlyWhenCompressing[] = {"Minimum saving", "Compression level", "Block size"};
    if (!_settings.compress) {
        _options.erase(std::remove_if(_options.begin(), _options.end(), [](const OptionItem& item) {
            return std::any_of(std::begin(OnlyWhenCompressing), std::end(OnlyWhenCompressing), [&](const char* label) { return item.label == label; });
        }), _options.end());
    }
    _options.push_back(OptionItem{"", _settings.moreSettings ? "Fewer settings" : "More settings", "Compression level, checking what's written, updates and the rest of what rarely needs changing.", [] { return std::string(); }, [this](int) {
        _settings.moreSettings = !_settings.moreSettings;
        saveSettings();
        _rebuildOptions = true;
    }, true});
}

/// What most people will want a say in, all in one place, the first time this opens. All of it can be changed later on the settings tab.
void App::buildWelcome() {
    _welcome.clear();
    const char* section = "When compressing";
    _welcome.push_back(installedGamesOption(section));
    _welcome.push_back(gameFilesOption(section, "Installing puts the game on the console, ready to play, compressed as it goes in. Saving leaves an NSP in the NSP folder."));
    _welcome.push_back(nspFolderOption(section));
    _welcome.push_back(OptionItem{section, "Check what's written", "Not checking is what most people want. Checking reads every byte back from the card and compares it before the original goes, which catches a failing card and takes a good deal longer.",
                                  [this] { return _settings.checkResult ? std::string("Yes, safer") : std::string("No, faster"); },
                                  [this](int) {
                                      _settings.checkResult = !_settings.checkResult;
                                      saveSettings();
                                  }});
    _welcome.push_back(minimumSavingOption("Which games are worth it"));
    _welcome.push_back(autoUpdateOption("This app"));
    _welcome.push_back(OptionItem{"", "Start", "All of this can be changed later, on the settings tab.", [] { return std::string(); }, [this](int) { finishWelcome(); }, true});
}

void App::finishWelcome() {
    _settings.welcomed = true;
    saveSettings();
    _screen = Screen::Main;
    _dirty = true;
}

}  // namespace hbp
