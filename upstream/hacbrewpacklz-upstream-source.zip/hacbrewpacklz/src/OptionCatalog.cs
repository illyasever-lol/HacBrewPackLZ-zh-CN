using System.Text;

namespace HacBrewPackLz;

/// <summary>Which jobs read an option.</summary>
[Flags]
internal enum OptionUse
{
    Build = 1,
    Convert = 2,
    Extract = 4,
}

internal enum OptionKind
{
    Toggle,
    Slider,
    Choice,
    Number,
    Text,
    Hex,
    File,
    Folder,

    /// <summary>Not a setting but something to do, with a button, among the options of the home screen and the GUI.</summary>
    Action,
}

internal sealed record OptionSpec(string Flag, string Label, OptionKind Kind, OptionUse Use, string Help)
{
    /// <summary>Whether a toggle's flag is on, with nothing stored meaning its default.</summary>
    public bool ToggleOn(string stored) => (stored.Length > 0 ? stored : DefaultApplies ? Default : "") == "1";

    /// <summary>What to store for a toggle's flag: nothing for its default, so a toggle that's on to begin with is kept off with a 0.</summary>
    public string ToggleValue(bool on) => on == ToggleOn("") ? "" : on ? "1" : "0";

    /// <summary>Also accepted on the command line.</summary>
    public string? Short { get; init; }

    /// <summary>What leaving it empty means, for people reading the console screen or the GUI.</summary>
    public string Placeholder { get; init; } = "";

    public string[] Choices { get; init; } = [];
    public int Min { get; init; }
    public int Max { get; init; }

    /// <summary>Starting value for a slider or a choice.</summary>
    public string Default { get; init; } = "";

    /// <summary>The home screen and the GUI go by the default as if it had been chosen, even though the command line doesn't.</summary>
    public bool DefaultApplies { get; init; }

    /// <summary>The toggle reads "on" when the flag is absent.</summary>
    public bool Inverted { get; init; }

    /// <summary>Help for the command line when it has to say more than the GUI does.</summary>
    public string? CommandHelp { get; init; }

    /// <summary>What an action's button says.</summary>
    public string Verb { get; init; } = "";
}

internal sealed record OptionGroup(string Title, OptionSpec[] Options);

/// <summary>Every option, in one place: the command line help, the console screen and the GUI are all made from it.</summary>
internal static class OptionCatalog
{
    private const OptionUse Rebuilds = OptionUse.Build | OptionUse.Convert;
    private const OptionUse All = OptionUse.Build | OptionUse.Convert | OptionUse.Extract;

    public static readonly OptionGroup Compression = new("Compression",
    [
        new("--nocompress", "Compress game data", OptionKind.Toggle, Rebuilds,
            "Stores the RomFS LZ4 compressed. Turned off, it is stored uncompressed, like hacBrewPack.")
        {
            Inverted = true, CommandHelp = "Store the RomFS uncompressed, like hacBrewPack",
        },
        new("--level", "Compression level", OptionKind.Slider, Rebuilds,
            "1 is the fastest and 12 the smallest. 9 is a good balance.")
        {
            Min = Lz4Encoder.MinLevel, Max = Lz4Encoder.MaxLevel, Default = "9",
            CommandHelp = "LZ4 level from 1 (fastest) to 12 (smallest), default 9",
        },
        new("--blocksize", "Block size", OptionKind.Choice, Rebuilds,
            "Larger blocks compress better. 64K is what retail games use.")
        {
            Choices = ["4K", "8K", "16K", "32K", "64K"], Default = "64K",
            CommandHelp = "Compression block size, power of two from 4K to 64K, default 64K",
        },
        new("--threads", "Threads", OptionKind.Number, Rebuilds,
            "How many processor threads to compress with.")
        {
            Min = 1, Max = 1024, Placeholder = "All of them",
            CommandHelp = "Number of compression threads, default all logical processors",
        },
    ]);

    public static readonly OptionGroup Worthwhile = new("Which titles are worth it",
    [
        new("--minsaving", "Minimum saving", OptionKind.Choice, OptionUse.Convert,
            "Titles that would save less than this are left out, so the time goes where it gains the most. You can still tick them yourself.")
        {
            Choices = ["Off", "5%", "10%", "15%", "20%", "25%", "30%", "40%", "50%"], Default = "5%", DefaultApplies = true,
            CommandHelp = "Skip titles that would save less than this percentage. Each one is analyzed first. Default off",
        },
        new("--hidesmall", "Hide games under 1 MB", OptionKind.Toggle, OptionUse.Convert | OptionUse.Extract,
            "Leaves out games that small with no update or DLC, like forwarders, which aren't worth listing.")
        {
            Default = "1", DefaultApplies = true,
            CommandHelp = "Leave out games under 1 MB with no update or DLC, like forwarders. On to begin with on the home screen and in the GUI",
        },
        new("--showcompressed", "Hide compressed games", OptionKind.Toggle, 0,
            "Leaves games off the list when they're already compressed, as when the copy this tool made is beside the original. The bottom of the list says how many are hidden.")
        {
            Inverted = true, CommandHelp = "On the home screen and in the GUI, list games that are already compressed too",
        },
    ]);

    public static readonly OptionGroup Output = new("Output",
    [
        new("--nspdir", "NSP folder", OptionKind.Folder, Rebuilds,
            "Where finished NSPs go.")
        {
            Placeholder = "Beside the source file",
            CommandHelp = "Set output nsp directory. Default when converting is beside the input, and when building .\\hacbrewpack_nsp\\",
        },
        new("--outdir", "Extract folder", OptionKind.Folder, OptionUse.Extract,
            "Where extracted files go, in a folder for each title.")
        {
            Placeholder = "Beside the source file",
            CommandHelp = "Set output directory when extracting, default is beside the input",
        },
        new("--tempdir", "Temporary folder", OptionKind.Folder, Rebuilds,
            "Only used for a solid NSZ that has to be gone back to. Nothing else needs one.")
        {
            Placeholder = "The NSP folder",
            CommandHelp = "Set directory for what's read of a solid NSZ that has to be gone back to, default is the output nsp directory",
        },
        new("--verify", "Check each finished NSP", OptionKind.Toggle, Rebuilds,
            "Reads the NSP back and checks every hash, block and table. Takes a while longer."),
        new("--keepncadir", "Also write the NCAs", OptionKind.Toggle, Rebuilds,
            "Copies the finished NCAs to the NCA folder as well.")
        {
            CommandHelp = "Also write the NCAs to the nca directory",
        },
        new("--ncadir", "NCA folder", OptionKind.Folder, Rebuilds,
            "Where those NCAs go.")
        {
            Placeholder = "hacbrewpack_nca",
            CommandHelp = "Set output nca directory path used by --keepncadir, default path is .\\hacbrewpack_nca\\",
        },
    ]);

    public static readonly OptionGroup Keys = new("Keys and signing",
    [
        new("--keyset", "Keys file", OptionKind.File, All,
            "Your console keys. prod.keys beside this program is found by itself.")
        {
            Short = "-k", Placeholder = "prod.keys beside this program",
            CommandHelp = "Set keyset filepath, default looks for keys.dat, keys.txt, keys.ini and prod.keys",
        },
        new("--keygeneration", "Key generation", OptionKind.Number, Rebuilds,
            "Which key area key encrypts the new NCAs.")
        {
            Min = 1, Max = 32, Placeholder = "1",
            CommandHelp = "Set keygeneration for encrypting key area, default keygeneration is 1",
        },
        new("--keyareakey", "Key area key 2", OptionKind.Hex, Rebuilds,
            "32 hex digits.")
        {
            Placeholder = "04040404040404040404040404040404",
            CommandHelp = "Set key area key 2 in hex with 16 bytes length",
        },
        new("--sdkversion", "SDK version", OptionKind.Hex, Rebuilds,
            "In hex. When converting, the default keeps each source's own version.")
        {
            Placeholder = "000C1100",
            CommandHelp = "Set SDK version in hex, default SDK version is 000C1100",
        },
        new("--plaintext", "Don't encrypt sections", OptionKind.Toggle, Rebuilds,
            "Writes the sections unencrypted and marks them as plaintext.")
        {
            CommandHelp = "Skip encrypting sections and set section header block crypto type to plaintext",
        },
        new("--nosignncasig2", "Don't sign NCAs", OptionKind.Toggle, Rebuilds,
            "Keeps the original ACID public key and skips the second NCA signature.")
        {
            CommandHelp = "Skip patching acid public key in npdm and signing nca header with acid public key",
        },
    ]);

    public static readonly OptionGroup Versions = new("Versions",
    [
        new("--titleversion", "Title version", OptionKind.Hex, Rebuilds,
            "In hex. The default is 0, or the source's version when converting.")
        {
            Placeholder = "From the source",
            CommandHelp = "Set title version in the content meta in hex, default 0, or the source's version when converting",
        },
        new("--requiredsystemversion", "Required system version", OptionKind.Hex, Rebuilds,
            "In hex. The default is 12.0.0 when compressing, or the source's if that is higher.")
        {
            Placeholder = "Worked out for you",
            CommandHelp = "Set required system version in the content meta in hex, default 30000000 (12.0.0) when compressing, otherwise 0, or the source's if higher when converting",
        },
    ]);

    public static readonly OptionGroup BuildFolders = new("Folders",
    [
        new("--exefsdir", "ExeFS folder", OptionKind.Folder, OptionUse.Build, "Must hold main.npdm.")
        {
            Placeholder = ".\\exefs",
            CommandHelp = "Set program exefs directory path, default path is .\\exefs\\",
        },
        new("--romfsdir", "RomFS folder", OptionKind.Folder, OptionUse.Build, "The game's data.")
        {
            Placeholder = ".\\romfs",
            CommandHelp = "Set program romfs directory path, default path is .\\romfs\\",
        },
        new("--logodir", "Logo folder", OptionKind.Folder, OptionUse.Build, "The boot logo files.")
        {
            Placeholder = ".\\logo",
            CommandHelp = "Set program logo directory path, default path is .\\logo\\",
        },
        new("--controldir", "Control folder", OptionKind.Folder, OptionUse.Build, "Must hold control.nacp.")
        {
            Placeholder = ".\\control",
            CommandHelp = "Set control romfs directory path, default path is .\\control\\",
        },
        new("--htmldocdir", "HtmlDocument folder", OptionKind.Folder, OptionUse.Build, "Optional in-game manual.")
        {
            Placeholder = "None",
            CommandHelp = "Set HtmlDocument romfs directory path",
        },
        new("--legalinfodir", "LegalInformation folder", OptionKind.Folder, OptionUse.Build, "Optional legal notices.")
        {
            Placeholder = "None",
            CommandHelp = "Set LegalInformation romfs directory path",
        },
        new("--output", "Output file", OptionKind.File, OptionUse.Build, "The NSP to write. The default is named after the title ID, in the NSP folder.")
        {
            Short = "-o", Placeholder = "<title id>.nsp in the NSP folder",
            CommandHelp = "Set output nsp filepath, for a single title. Overrides --nspdir",
        },
        new("--noromfs", "No RomFS", OptionKind.Toggle, OptionUse.Build, "Builds the Program NCA without a RomFS section.")
        {
            CommandHelp = "Skip creating program romfs section",
        },
        new("--nologo", "No logo", OptionKind.Toggle, OptionUse.Build, "Builds the Program NCA without a logo section.")
        {
            CommandHelp = "Skip creating program logo section",
        },
    ]);

    public static readonly OptionGroup BuildTitle = new("Title",
    [
        new("--titleid", "Title ID", OptionKind.Hex, OptionUse.Build, "16 hex digits. Replaces the ID in the NCAs, the NPDM and the NACP.")
        {
            Placeholder = "From main.npdm",
            CommandHelp = "Use specified titleid for creating ncas and patch titleid in npdm and nacp",
        },
        new("--titlename", "Title name", OptionKind.Text, OptionUse.Build, "Replaces the name in the NACP for all languages, up to 512 bytes.")
        {
            Placeholder = "From control.nacp",
            CommandHelp = "Change title name in nacp for all languages, max size is 512 bytes",
        },
        new("--titlepublisher", "Publisher", OptionKind.Text, OptionUse.Build, "Replaces the publisher in the NACP for all languages, up to 256 bytes.")
        {
            Placeholder = "From control.nacp",
            CommandHelp = "Change title publisher in nacp for all languages, max size is 256 bytes",
        },
        new("--nopatchnacplogo", "Keep the NACP logo setting", OptionKind.Toggle, OptionUse.Build, "Normally logo handling is changed to automatic.")
        {
            CommandHelp = "Skip changing logo handling to auto in NACP",
        },
    ]);

    public static readonly OptionGroup Updates = new("Updates",
    [
        new("--noautoupdate", "Automatic updates", OptionKind.Toggle, 0,
            "Each time it opens, it looks for a newer version and installs it. Whatever it gets has to carry the right signature.")
        {
            Inverted = true, CommandHelp = "On the home screen and in the GUI, don't look for a newer version when opening",
        },
    ]);

    public static readonly OptionGroup[] Groups = [Compression, Worthwhile, Output, Keys, Versions, BuildFolders, BuildTitle, Updates];

    /// <summary>Looks for a newer version there and then. The command line has the update command instead.</summary>
    public static readonly OptionSpec CheckForUpdates = new("check-for-updates", "Check for updates", OptionKind.Action, 0,
        "Looks for a newer version now, and installs it if there is one.")
    {
        Verb = "Check now",
    };

    /// <summary>
    /// The groups a list of titles uses, leaving out what only building from folders needs, with checking for updates
    /// beside the setting that does it by itself.
    /// </summary>
    public static readonly OptionGroup[] GeneralGroups =
        [Compression, Worthwhile, Output, Keys, Versions, Updates with { Options = [.. Updates.Options, CheckForUpdates] }];

    public static IEnumerable<OptionSpec> AllOptions => Groups.SelectMany(g => g.Options);
}

/// <summary>A wrapped help text, laid out for whatever width the window has right now.</summary>
internal static class HelpText
{
    private const int FlagColumn = 26;

    public static List<(string text, UiLevel level)> Lines(int width)
    {
        var lines = new List<(string, UiLevel)>();
        void Heading(string text)
        {
            lines.Add(("", UiLevel.Info));
            lines.Add((text, UiLevel.Heading));
        }
        void Paragraph(string text)
        {
            foreach (string row in Terminal.Wrap(text, width))
                lines.Add((row, UiLevel.Info));
        }
        void Command(string command, string text)
        {
            foreach (string row in Terminal.Wrap($"  {command}", width, 4))
                lines.Add((row, UiLevel.Info));
            foreach (string row in Terminal.Wrap($"    {text}", width, 4))
                lines.Add((row, UiLevel.Detail));
        }
        void Flag(string flag, string text)
        {
            int column = Math.Min(FlagColumn, Math.Max(width / 3, 12));
            bool fits = flag.Length + 2 < column;
            string start = fits ? flag.PadRight(column) : flag;
            if (!fits)
                lines.Add((flag, UiLevel.Info));
            string body = fits ? start + text : new string(' ', column) + text;
            foreach (string row in Terminal.Wrap(body, width, column))
                lines.Add((row, UiLevel.Info));
        }

        lines.Add(("Usage", UiLevel.Heading));
        Command("hacbrewpacklz", "Open the home screen when double clicked, or build an NSP from folders in a command window.");
        Command("hacbrewpacklz convert [options] <file or folder>...", "Rebuild NSP, NSZ, XCI or XCZ files as compressed NSPs.");
        Command("hacbrewpacklz analyze [options] <file or folder>...", "Show how large the result would be, without writing anything. With no inputs, the folders of a build.");
        Command("hacbrewpacklz extract [options] <file or folder>...", "Extract NSP, NSZ, XCI or XCZ files to folders.");
        Command("hacbrewpacklz verify -k <keyset> <file.nsp> [--romfsdir <dir>] [--exefsdir <dir>]", "Check a finished NSP, and compare it with folders if given.");
        Command("hacbrewpacklz send <file or folder>...", "Share NSP, NSZ, XCI or XCZ files, or folders of games, with hacBrewPackLZ on a Switch, over the network or a USB cable, so it can install them. Takes no options. Runs until Ctrl+C.");
        Command("hacbrewpacklz menu", "Open the home screen.");
        Command("hacbrewpacklz update", "Install the latest version, if it's newer than this one.");

        Heading("About");
        Paragraph("Builds an installable NSP like hacBrewPack, with the RomFS section of the Program NCA stored LZ4 compressed through the NCA compression layer. Input files and folders are never modified.");
        lines.Add(("", UiLevel.Info));
        Paragraph("Dropping game files or folders onto the program opens them on the home screen. Put prod.keys beside the program, or use -k.");

        Heading("Converting, analyzing and extracting");
        Paragraph("Folders are searched for .nsp, .nsz, .xci and .xcz files, including subfolders. An update given with its base game is applied to it, so the result is one title: the newest update wins and a repacked title holds no ticket. DLC stays separate. An update without its base game can't be processed. Output goes beside the input unless you choose otherwise.");
        lines.Add(("", UiLevel.Info));
        Flag("--only <list>", "Only these titles, by title ID or part of the name, separated by commas");
        Flag("--skip <list>", "Leave these titles out, by title ID or part of the name, separated by commas");

        foreach (var group in OptionCatalog.Groups)
        {
            Heading(group.Title);
            foreach (var option in group.Options)
                Flag(option.Short is null ? option.Flag : $"{option.Short}, {option.Flag}", option.CommandHelp ?? option.Help);
        }

        Heading("Other");
        Flag("-h, --help", "Display this help");
        Flag("--backupdir", "Accepted for compatibility and ignored, source files are never modified");
        return lines;
    }

    public static string Plain(int width)
    {
        var text = new StringBuilder();
        foreach (var (line, _) in Lines(width))
            text.AppendLine(line);
        return text.ToString();
    }
}

/// <summary>The choices made on the console screen or in the GUI, kept between runs as ordinary command line options.</summary>
internal sealed class Settings
{
    private readonly Dictionary<string, string> _values = new(StringComparer.Ordinal);

    private static string FilePath =>
        Environment.GetEnvironmentVariable("HACBREWPACKLZ_SETTINGS")
        ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), AppInfo.Name, "settings.txt");

    public static Settings Load()
    {
        var settings = new Settings();
        try
        {
            foreach (string line in File.ReadLines(FilePath))
            {
                int eq = line.IndexOf('=');
                string flag = eq > 0 ? line[..eq] : line;
                string value = eq > 0 ? line[(eq + 1)..] : "1";
                if (OptionCatalog.AllOptions.Any(o => o.Flag == flag))
                    settings._values[flag] = value;
            }
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException)
        {
            // No settings yet, or they can't be read: start from the defaults.
        }
        return settings;
    }

    public void Save()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
            File.WriteAllLines(FilePath, _values.Select(v => $"{v.Key}={v.Value}"));
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException)
        {
            Ui.Warn($"Couldn't save the settings: {e.Message}");
        }
    }

    /// <summary>The value as entered, with a toggle's being "1" when its flag is on. Empty means the default.</summary>
    public string Get(string flag) => _values.GetValueOrDefault(flag, "");

    public void Set(string flag, string value)
    {
        if (value.Length == 0)
            _values.Remove(flag);
        else
            _values[flag] = value;
    }

    /// <summary>Parses just the options a job reads, so it reports problems in the same words as the command line.</summary>
    public Options ToOptions(OptionUse use) => Options.Parse(ToArguments(use));

    public string[] ToArguments(OptionUse use)
    {
        var args = new List<string>();
        foreach (var option in OptionCatalog.AllOptions)
        {
            if ((option.Use & use) == 0)
                continue;
            if (!_values.TryGetValue(option.Flag, out string? value))
            {
                if (!option.DefaultApplies)
                    continue;
                value = option.Default;
            }
            if (option.Kind != OptionKind.Toggle)
                args.Add($"{option.Flag}={value}");
            else if (value == "1")
                args.Add(option.Flag);
        }
        return args.ToArray();
    }
}
